## 机器学习基石作业

- Lec1~Lec4：作业1
- Lec5~Lec8：作业2
- Lec9~Lec12：作业3
- Lec13~Lec16：作业4

### 机器学习技法作业

- Lec1~Lec4：作业1
- Lec5~Lec8：作业2
- Lec9~Lec12：作业3
- Lec13~Lec16：作业4

### 说明

① 此处主要放置关于需要编程题目的代码。为便于查看，为jupyter notebook格式

② 各作业的具体题目，以(.png放置)以及对应的数据集

③ 具体的解答过程和答案见[博客](http://acecoooool.com/)

